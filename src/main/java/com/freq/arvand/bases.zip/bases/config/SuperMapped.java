package com.freq.arvand.bases.config;

import java.util.List;

public class SuperMapped {
    public SuperMapped(List<MapperInfo> mapperInfo) {

    }
}
