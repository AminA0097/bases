package com.freq.arvand.bases.mapping;

public enum SqlCommandType {
    SELECT, INSERT, UPDATE
}
